The site is a polished, single-page blog prototype: the HTML lays out the sections, CSS makes it responsive, and JavaScript powers browsing and writing. One important detail is that posts and saved stories are stored only in the browser, while the newsletter form currently just displays a confirmation rather than subscribing to a real service.

Fieldnotes is a single-page blogging website for browsing and sharing reflective stories about life, places, culture, and ideas.

Browse stories: The home page highlights an editor’s pick, then lists the latest stories with author, date, category, and estimated reading time. There’s also a “Most read” list.
Find and filter: Readers can search by title, author, category, or summary; filter by category; and switch to see only saved stories. Press / to focus the search box.
Read and save: Selecting a story opens it in a reading dialog. Stories can be bookmarked, and saved selections remain in the browser.
Write a story: The compose form lets a reader enter a title, byline, category, summary, story text, and optional image URL. Published stories appear in the list and are saved on that device.
Newsletter form: It shows a confirmation message when an email is entered, but it is not connected to an actual mailing list.
The files divide the work: index.html defines the page and forms, styles.css controls the visual design and mobile layout, and script.js implements search, filters, dialogs, bookmarks, and publishing. This is a front-end prototype; it has no server or shared database, so stories are not published for other visitors to see.